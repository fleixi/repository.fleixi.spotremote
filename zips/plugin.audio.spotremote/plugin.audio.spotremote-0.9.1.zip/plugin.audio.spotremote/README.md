# plugin.audio.spotremote
Kodi-Addon to remotely control a running Spotify-Client (Linux x86/amd64 only)

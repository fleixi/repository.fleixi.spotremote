# service.audio.spotremote
Kodi-Service to automatic start Spotremote addon if Spotify is playing
